package uniandes.dpoo.triqui.interfaz;

import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PanelBotones extends JPanel implements ActionListener
{
	private VentanaTriqui ventana;
	int cantidad=0;
	
	public PanelBotones(VentanaTriqui padre)
	{
		this.ventana=padre;
		JButton reiniciar=new JButton("Reiniciar");
		add(reiniciar,BorderLayout.SOUTH);
		reiniciar.addActionListener(this);
		
		
	}

	public void actionPerformed(ActionEvent e)
	{
		String comando = e.getActionCommand();
		System.out.println("com"+comando);
		
		ventana.repaint();
		ventana.reiniciar();
		
	}

	public void actualizarCantidadJugadas(int numero)
	{
		
	}
}
